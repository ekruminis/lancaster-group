public class Game implements Runnable {
    // main game loop

    public void run(){

        while(true){

        }
    }

}
